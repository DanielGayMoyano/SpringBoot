package curso.java;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
