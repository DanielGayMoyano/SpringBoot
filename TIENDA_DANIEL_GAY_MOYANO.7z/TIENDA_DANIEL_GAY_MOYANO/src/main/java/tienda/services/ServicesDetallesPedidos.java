package tienda.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tienda.model.pojos.Detalles_Pedido;
import tienda.model.repository.DetallesPedidoRepository;

@Service
public class ServicesDetallesPedidos {

	@Autowired
	DetallesPedidoRepository detallesPedidoRepository;

	public void insertarDetallesPedido(Detalles_Pedido detallesPedido) {
		detallesPedidoRepository.save(detallesPedido);
	}


	public Detalles_Pedido recuperarDetallesPedido(int id) {
		return detallesPedidoRepository.getById(id);
	}

	public void borrarDetallesPedido(int id) {
		detallesPedidoRepository.deleteById(id);
	}

	public List<Detalles_Pedido> recuperarDetallesPedidos(String query) {
		return detallesPedidoRepository.findAll();
	}

}
