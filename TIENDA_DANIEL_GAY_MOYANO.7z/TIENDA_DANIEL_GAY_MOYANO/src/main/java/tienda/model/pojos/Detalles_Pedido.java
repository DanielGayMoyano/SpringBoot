package tienda.model.pojos;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "detalles_pedido")
public class Detalles_Pedido {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private int idPedido;
	private int idProducto;
	private float precioUnidad;
	private int unidades;
	private float impuesto;
	private double total;

	public Detalles_Pedido(float precioUnidad, int unidades, float impuesto, double total) {
		super();
		this.precioUnidad = precioUnidad;
		this.unidades = unidades;
		this.impuesto = impuesto;
		this.total = total;
	}

}
