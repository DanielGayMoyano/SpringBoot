package tienda.controllers;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import tienda.model.pojos.Pedidos;
import tienda.model.pojos.Productos;
import tienda.model.pojos.Usuarios;
import tienda.services.ServicesPedidos;
import tienda.services.ServicesProductos;
import tienda.services.ServicesUsuarios;
import tienda.utils.Routes;

@Controller
@RequestMapping(value = "", method = { RequestMethod.GET, RequestMethod.POST })
public class PedidoController {

	List<Productos> carrito = new ArrayList<Productos>();

	

	@Autowired
	ServicesProductos servicesProductos;

	@Autowired
	ServicesPedidos servicesPedidos;

	@GetMapping("/listaPedidos")
	public String listaPedidos(Model model, HttpSession sesion) {

		Usuarios usuario = (Usuarios) sesion.getAttribute("usuario");
		if (usuario == null) {
			return Routes.LOGIN;
		} else {
			List<Pedidos> listaPedidos = servicesPedidos.recuperarPedidos(String.valueOf(usuario.getId()));
			model.addAttribute("listaPedidos", listaPedidos);
			return Routes.PEDIDO;
		}
	}

	@GetMapping("/realizarPedido")
	public String realizarPedido(HttpSession sesion) {
		if (sesion.getAttribute("usuario") != null) {

			double total = 0;
			List<Productos> almacen = servicesProductos.recuperarProductos();
			// System.out.println(almacen);
			List<Productos> carrito = (List<Productos>) sesion.getAttribute("carrito");
			//System.out.println(carrito);
			for (Productos producto : carrito) {
				//System.out.println(producto);
				for (Productos p : almacen) {
					if (producto.getId() == p.getId()) {
						if (producto.getStock() > p.getStock()) {
							producto.setStock(p.getStock());
						}
					}
				}
				total = total + (producto.getPrecio() * producto.getStock());
				// total+=(producto.getPrecio()*producto.getStock());
				//System.out.println(total);
			}
			//System.out.println("precio total despues de impuestos:" + total);
			// System.out.println(carrito);
			sesion.setAttribute("total", total);
			sesion.setAttribute("carrito", carrito);
			return Routes.METODO_PAGO;
		} else {
			return Routes.LOGIN;
		}
	}

	@GetMapping("/crearPedido")
	public String crearPedido(@RequestParam String paymentMethod, Model model, HttpSession sesion) {
		Usuarios usuario = (Usuarios) sesion.getAttribute("usuario");
		if (usuario == null) {

		}
		String metodoPago = paymentMethod;
		double total = 0;
		try {
			total = (double) sesion.getAttribute("total");
		} catch (Exception e) {
			e.printStackTrace();
		}
		//System.out.println(total + " " + metodoPago);

		// PedidoDAO pedidoDao = new PedidoDAO();

		List<Pedidos> listaPedidos = servicesPedidos.recuperarPedidos();
		List<Pedidos> carrito = (List<Pedidos>) sesion.getAttribute("carrito");
		//System.out.println(carrito);
		Pedidos aux = listaPedidos.get(listaPedidos.size() - 1);
		Pedidos pedidoPojo = new Pedidos();

		pedidoPojo.setId_usuario(usuario.getId());
		pedidoPojo.setFecha(new Timestamp(System.currentTimeMillis()));
		pedidoPojo.setMetodo_Pago(metodoPago);
		
		pedidoPojo.setEstado("PE");// poner con las iniciales
		pedidoPojo.setNum_Factura(usuario.getNombre().concat(String.valueOf(aux.getId())));
		pedidoPojo.setTotal(total);
		System.out.println(pedidoPojo);
		sesion.setAttribute("pedido", pedidoPojo);
		model.addAttribute("listaPedidos");
		servicesPedidos.guardarPedido(pedidoPojo);
		return Routes.PEDIDO;
	}

}
